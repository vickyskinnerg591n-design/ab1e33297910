// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Drain node gracefully");
  std::fflush(stdout);
  return lionss_run_workload("k8s-drain");
}
