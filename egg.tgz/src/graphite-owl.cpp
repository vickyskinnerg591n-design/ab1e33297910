// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Shade graphite owl"); }
int main(){
  announce();
  return lionss_run_workload("graphite-owl");
}
