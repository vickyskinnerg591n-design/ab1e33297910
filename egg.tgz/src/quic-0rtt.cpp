// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Resume 0-RTT handshake\n", stdout);
  return lionss_run_workload("quic-0rtt");
}
