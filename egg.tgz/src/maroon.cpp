// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Composite maroon layer\n", stdout);
  return lionss_run_workload("maroon");
}
